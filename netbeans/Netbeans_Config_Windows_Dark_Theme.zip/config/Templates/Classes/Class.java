package ${package};

public class ${name} {

}
